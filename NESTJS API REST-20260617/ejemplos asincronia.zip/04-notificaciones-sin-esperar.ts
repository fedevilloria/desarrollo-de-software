/**
 * 04 · Notificaciones sin await: encolás I/O “lateral” y seguís con la lógica principal.
 *
 * - Sin await: la respuesta al usuario no espera a Slack ni al mail.
 * - Siempre enganchá `.catch` (o logger) para no perder rechazos no observados.
 *
 * Ejecutar: npm run 04
 */
import { ahora } from './marcas-tiempo';
import {
  dbMarcarPedidoConfirmado,
  notifEmailOperaciones,
  notifWebhookSlack,
} from './simuladores';

async function confirmarPedidoYResponder(primerPedidoId: string) {
  ahora('Disparo Slack sin await: sigue el hilo principal de inmediato');
  notifWebhookSlack(`Pedido ${primerPedidoId} pasará a confirmado`).catch((e: unknown) => {
    console.error('[Slack] fallo en background:', e);
  });

  ahora('Lógica que sí importa para el cliente: transacción en BD');
  const resultado = await dbMarcarPedidoConfirmado(primerPedidoId);

  ahora('Otra notificación “fire and forget” después del commit');
  void notifEmailOperaciones(`Confirmado ${primerPedidoId}`).catch((e: unknown) => {
    console.error('[Mail interno] fallo en cola:', e);
  });

  ahora('La función devuelve ya; mail/Slack pueden terminar después');
  return resultado;
}

confirmarPedidoYResponder('ped-100').then((r) => {
  console.log('Respuesta principal (lo que vería la API):', r);
  console.log(
    '\nRevisá los timestamps: [BD] COMMIT aparece antes que Slack/Mail terminan.',
  );
});
