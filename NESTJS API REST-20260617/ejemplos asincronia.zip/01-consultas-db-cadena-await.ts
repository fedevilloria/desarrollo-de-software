/**
 * 01 · Consultas a la BD en cadena: cada paso necesita datos del anterior → await entre medio.
 *
 * Flujo: usuario → pedidos de ese usuario → tomamos el primero y leemos líneas
 * (sin combinar en un solo SQL a propósito: mostramos dependencias por código).
 *
 * Ejecutar: npm run 01
 */
import { ahora } from './marcas-tiempo';
import {
  dbLineasPorPedido,
  dbPedidosActivosPorUsuario,
  dbUsuarioPorId,
} from './simuladores';

async function detallePrimerPedidoAbierto(usuarioId: string) {
  ahora('Paso 1: necesito la fila de usuario antes de buscar sus pedidos');
  const usuario = await dbUsuarioPorId(usuarioId);

  ahora('Paso 2: el WHERE usa usuario.id devuelto arriba');
  const pedidos = await dbPedidosActivosPorUsuario(usuario.id);

  if (pedidos.length === 0) {
    return { usuario, pedido: null, lineas: [] as const };
  }

  const primer = pedidos[0];
  ahora('Paso 3: el id del pedido viene del resultado anterior → otra consulta');
  const lineas = await dbLineasPorPedido(primer.id);

  return { usuario, pedido: primer, lineas };
}

detallePrimerPedidoAbierto('usr-demo-1').then((v) => {
  console.log(JSON.stringify(v, null, 2));
});
