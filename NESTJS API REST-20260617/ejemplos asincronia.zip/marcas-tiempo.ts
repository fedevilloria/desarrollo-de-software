/**
 * Utilidad común: marca relativa al inicio del proceso (ms, alta resolución).
 * En Node 18+ existe performance global.
 */
const inicio = performance.now();

export function ahora(etiqueta: string): void {
  const delta = (performance.now() - inicio).toFixed(2);
  console.log(`[t + ${delta} ms] ${etiqueta}`);
}
