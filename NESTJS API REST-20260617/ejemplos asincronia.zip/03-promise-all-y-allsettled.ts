/**
 * 03 · Datos críticos en Promise.all + datos secundarios en Promise.allSettled.
 *
 * - all: si una consulta esencial falla, el handler puede responder 500.
 * - allSettled: promociones lentas / réplica inestable + KPIs: queremos ver
 *   qué pasó en cada una sin tumbar la respuesta principal.
 *
 * Ejecutar: npm run 03
 */
import { ahora } from './marcas-tiempo';
import {
  dbKpisInternos,
  dbPedidosActivosPorUsuario,
  dbPromocionesDelMes,
  dbResumenStockGlobal,
  dbUsuarioPorId,
} from './simuladores';

async function armarPanelOperaciones(usuarioId: string) {
  ahora('Bloque A — Promise.all: lecturas que necesitamos todas para armar el núcleo');
  const [usuario, pedidos, stock] = await Promise.all([
    dbUsuarioPorId(usuarioId),
    dbPedidosActivosPorUsuario(usuarioId),
    dbResumenStockGlobal(),
  ]);

  ahora('Bloque B — Promise.allSettled: extras; un fallo no cancela al otro');
  const extras = await Promise.allSettled([
    dbPromocionesDelMes(),
    dbKpisInternos(),
  ]);

  const promos =
    extras[0].status === 'fulfilled'
      ? extras[0].value
      : { error: extras[0].reason?.message ?? extras[0].reason };
  const kpis = extras[1].status === 'fulfilled' ? extras[1].value : null;

  return {
    nucleo: {
      usuario: usuario.email,
      pedidosAbiertos: pedidos.length,
      stockDisponible: stock.unidadesDisponibles,
    },
    extras: { promociones: promos, kpis },
  };
}

armarPanelOperaciones('usr-demo-1').then((panel) => {
  console.log(JSON.stringify(panel, null, 2));
});
