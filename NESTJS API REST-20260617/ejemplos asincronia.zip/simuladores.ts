import { ahora } from './marcas-tiempo';

function demorar<T>(ms: number, valor: T): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(valor), ms));
}

function demorarRechazo(ms: number, error: Error): Promise<never> {
  return new Promise((_, reject) => setTimeout(() => reject(error), ms));
}

export type Usuario = { id: string; email: string; nombre: string };

export type Pedido = { id: string; usuarioId: string; estado: string; totalCents: number };

export type LineaPedido = { sku: string; cantidad: number; precioUnitCents: number };

/** Simula SELECT por PK. */
export function dbUsuarioPorId(usuarioId: string): Promise<Usuario> {
  ahora(`[BD] SELECT * FROM usuarios WHERE id = '${usuarioId}'`);
  return demorar(240, {
    id: usuarioId,
    email: 'cliente@demo.edu',
    nombre: 'Ana Docente',
  }).then((u) => {
    ahora(`[BD] 1 fila usuario ${u.email}`);
    return u;
  });
}

/** Simula SELECT de pedidos por FK usuario. */
export function dbPedidosActivosPorUsuario(usuarioId: string): Promise<Pedido[]> {
  ahora(`[BD] SELECT * FROM pedidos WHERE usuario_id = '${usuarioId}' AND estado = 'abierto'`);
  return demorar(260, [
    {
      id: 'ped-100',
      usuarioId,
      estado: 'abierto',
      totalCents: 15_900,
    },
    {
      id: 'ped-101',
      usuarioId,
      estado: 'abierto',
      totalCents: 4_200,
    },
  ]).then((rows) => {
    ahora(`[BD] ${rows.length} pedidos abiertos`);
    return rows;
  });
}

/** Simula SELECT de líneas por FK pedido. */
export function dbLineasPorPedido(pedidoId: string): Promise<LineaPedido[]> {
  ahora(`[BD] SELECT * FROM lineas_pedido WHERE pedido_id = '${pedidoId}'`);
  return demorar(200, [
    { sku: 'YERBA-1KG', cantidad: 2, precioUnitCents: 5200 },
    { sku: 'TERMO', cantidad: 1, precioUnitCents: 5500 },
  ]).then((lines) => {
    ahora(`[BD] ${lines.length} líneas para ${pedidoId}`);
    return lines;
  });
}

/** Otra lectura para armar bloques en paralelo (Promise.all). */
export function dbResumenStockGlobal(): Promise<{ unidadesDisponibles: number }> {
  ahora('[BD] SELECT COUNT(*) disponibles FROM inventario…');
  return demorar(280, { unidadesDisponibles: 4_820 }).then((r) => {
    ahora(`[BD] stock agregado = ${r.unidadesDisponibles}`);
    return r;
  });
}

/** Lectura “nice to have”: puede fallar sin tumbar la pantalla. */
export function dbPromocionesDelMes(): Promise<{ codigo: string; dtoPct: number }[]> {
  ahora('[BD] SELECT * FROM promociones WHERE vigente = 1…');
  return demorarRechazo(180, new Error('BD réplica promociones: timeout'));
}

/** Otra secundaria lenta pero que sí resuelve. */
export function dbKpisInternos(): Promise<{ enviosHoy: number }> {
  ahora('[BD] SELECT métricas agregadas (lento)…');
  return demorar(350, { enviosHoy: 142 }).then((k) => {
    ahora(`[BD] KPI envíos_hoy=${k.enviosHoy}`);
    return k;
  });
}

/** Escritura principal del flujo de negocio. */
export function dbMarcarPedidoConfirmado(pedidoId: string): Promise<{ pedidoId: string; confirmadoEn: string }> {
  ahora(`[BD] UPDATE pedidos SET estado='confirmado' WHERE id='${pedidoId}'…`);
  return demorar(190, {
    pedidoId,
    confirmadoEn: new Date().toISOString(),
  }).then((r) => {
    ahora('[BD] COMMIT pedido confirmado');
    return r;
  });
}

/**
 * Cola de notificaciones (Slack, webhooks). No es “BD” pero tarda red.
 * Pensada para dispararla **sin await** y seguir con la lógica principal.
 */
export function notifWebhookSlack(mensaje: string): Promise<{ entregado: boolean }> {
  ahora(`[Slack] POST mensaje: ${mensaje.slice(0, 40)}…`);
  return demorar(400, { entregado: true }).then((x) => {
    ahora('[Slack] 200 OK');
    return x;
  });
}

/** Mail interno: también mock de cola. */
export function notifEmailOperaciones(asunto: string): Promise<{ id: string }> {
  ahora(`[Mail interno] encolado: ${asunto}`);
  return demorar(320, { id: 'mq-mail-1' }).then((r) => {
    ahora('[Mail interno] proveedor aceptó');
    return r;
  });
}
