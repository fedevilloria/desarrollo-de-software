/**
 * 02 · Consultas anidadas con await: dentro del mismo request armamos un árbol
 * usuario → varios pedidos → **por cada** pedido las líneas.
 *
 * Acá el await dentro del bucle es **necesario** si procesás en serie;
 * si las líneas de cada pedido son independientes, podrías usar Promise.all
 * (ver comentario al final — otro archivo enfoca paralelismo).
 *
 * Ejecutar: npm run 02
 */
import { ahora } from './marcas-tiempo';
import {
  dbLineasPorPedido,
  dbPedidosActivosPorUsuario,
  dbUsuarioPorId,
  type LineaPedido,
  type Pedido,
} from './simuladores';

async function inventarioAnidadoPorPedido(usuarioId: string) {
  const usuario = await dbUsuarioPorId(usuarioId);
  const pedidos = await dbPedidosActivosPorUsuario(usuario.id);

  ahora('Anidación: por cada pedido abro otra consulta (serie)');
  const conLineas: { pedido: Pedido; lineas: LineaPedido[] }[] = [];

  for (const p of pedidos) {
    const lineas = await dbLineasPorPedido(p.id);
    conLineas.push({ pedido: p, lineas });
  }

  return { usuario, pedidosConLineas: conLineas };
}

inventarioAnidadoPorPedido('usr-demo-1').then((r) => {
  console.log(
    JSON.stringify(
      r,
      null,
      2,
    ),
  );
  console.log(
    '\nNota: si el negocio permite, `Promise.all(pedidos.map(p => dbLineasPorPedido(p.id)))` evita la serie.',
  );
});
