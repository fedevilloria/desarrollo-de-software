import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { OrderLine } from './order-line.entity';
import { User } from './user.entity';

@Entity('orders')
export class Order {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', length: 32 })
  status: string;

  @CreateDateColumn({ name: 'placed_at' })
  placedAt: Date;

  /**
   * Lado propietario: FK `user_id` en `orders`.
   * DER: Order * —— 1 User.
   */
  @ManyToOne(() => User, (u) => u.orders, { nullable: false })
  @JoinColumn({ name: 'user_id' })
  user: User;

  /** DER: Order 1 —— * OrderLine (inverso; FKs en `order_lines.order_id`). */
  @OneToMany(() => OrderLine, (line) => line.order)
  lines: OrderLine[];
}
