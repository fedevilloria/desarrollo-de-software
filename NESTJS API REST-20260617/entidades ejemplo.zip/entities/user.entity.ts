import {
  Column,
  Entity,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Order } from './order.entity';
import { Profile } from './profile.entity';

@Entity('users')
export class User {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', unique: true })
  email: string;

  /** DER: User 1 —— * Order (lado inverso; FK vive en `orders.user_id`). */
  @OneToMany(() => Order, (o) => o.user)
  orders: Order[];

  /** DER: User 1 —— 0..1 Profile (lado inverso; FK `user_id` en tabla `profiles`). */
  @OneToOne(() => Profile, (p) => p.user)
  profile: Profile;
}
