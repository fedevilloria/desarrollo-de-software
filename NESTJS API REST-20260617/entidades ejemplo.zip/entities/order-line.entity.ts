import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Order } from './order.entity';
import { Product } from './product.entity';

/**
 * Tabla intermedia pedido ↔ producto con atributos de relación (cantidad, precio congelado).
 * Evita N:M directo: en el DER son dos N:1 hacia Order y Product.
 */
@Entity('order_lines')
export class OrderLine {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  /** Atributo de la línea de pedido (no del producto catálogo). */
  @Column({ type: 'int' })
  quantity: number;

  /** Precio unitario al momento de la compra (histórico), en centavos. */
  @Column({ type: 'int', name: 'unit_price_cents' })
  unitPriceCents: number;

  /**
   * Lado propietario: `order_lines.order_id` → `orders.id`.
   * DER: OrderLine * —— 1 Order.
   */
  @ManyToOne(() => Order, (o) => o.lines, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'order_id' })
  order: Order;

  /**
   * Lado propietario: `order_lines.product_id` → `products.id`.
   * DER: OrderLine * —— 1 Product.
   */
  @ManyToOne(() => Product, (p) => p.orderLines)
  @JoinColumn({ name: 'product_id' })
  product: Product;
}
