import {
  Column,
  Entity,
  JoinTable,
  ManyToMany,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { OrderLine } from './order-line.entity';
import { Tag } from './tag.entity';

@Entity('products')
export class Product {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', unique: true })
  sku: string;

  @Column({ type: 'varchar' })
  name: string;

  @Column({ type: 'int' })
  priceCents: number;

  /** DER: Product 1 —— * OrderLine (inverso; mismo rol “líneas que citan este producto”). */
  @OneToMany(() => OrderLine, (line) => line.product)
  orderLines: OrderLine[];

  /**
   * N:M con tabla puente `product_tags` (sin columnas de negocio extra).
   * @JoinTable en este lado = TypeORM crea/gestiona filas product_id + tag_id.
   * DER: Product * —— * Tag vía entidad asociativa implícita `product_tags`.
   */
  @ManyToMany(() => Tag, (tag) => tag.products)
  @JoinTable({
    name: 'product_tags',
    joinColumn: { name: 'product_id', referencedColumnName: 'id' },
    inverseJoinColumn: { name: 'tag_id', referencedColumnName: 'id' },
  })
  tags: Tag[];
}
