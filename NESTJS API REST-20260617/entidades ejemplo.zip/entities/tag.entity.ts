import {
  Column,
  Entity,
  ManyToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Product } from './product.entity';

@Entity('tags')
export class Tag {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'varchar', unique: true })
  slug: string;

  @Column({ type: 'varchar', length: 96 })
  label: string;

  /** Lado inverso del N:M; no lleva @JoinTable. */
  @ManyToMany(() => Product, (p) => p.tags)
  products: Product[];
}
